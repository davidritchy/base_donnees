<?php
namespace App\Models;

class ExampleModel{
    public function getData(){
        return "Hello from Model to Controller";
    }
}