<?php
define('BASE', '/dashboard/base_de_donnes/mvc');
define('ASSET', '/dashboard/base_de_donnes/mvc/public');