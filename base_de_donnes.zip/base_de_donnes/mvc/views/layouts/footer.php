</main>
<footer>
    <p>2024 tous les droits reserves!</p>
</footer>
</body>
</html>